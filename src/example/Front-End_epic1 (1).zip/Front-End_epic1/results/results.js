const time_sec = 6000; //ms
const step_sec = 1;

function outNum(num, elem) {
  let l = document.querySelector('#' + elem);
  n = 0;
  let t = Math.round(time_sec/(num/step_sec));
  let interval = setInterval(() => {
    n = n + step;
    if (n == num) {
      clearInterval(interval);
    }
    l.innerHTML = n;
  }, t);
}

outNum(100, 's');
